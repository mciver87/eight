// var $ = require('jquery');


// var init = function() {
// 	$('body').on('click', '.abt-panels h1', function(evt){
// 		console.log('jeu')
// 		console.log(this)
// 		console.log(evt.target)
// 		$(this).closest('.abt-panels').find('.panel').removeClass('active')
// 		$(this).closest('.panel').addClass('active')
// 	});
// };

// exports.init = init;